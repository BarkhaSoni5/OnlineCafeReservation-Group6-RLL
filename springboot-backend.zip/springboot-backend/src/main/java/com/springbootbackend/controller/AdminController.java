package com.springbootbackend.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import com.springbootbackend.Service.AdminService;
import com.springbootbackend.model.Admin;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/admin")
public class AdminController {

    private final AdminService adminService;
    
    

    @Autowired
    public AdminController(AdminService adminService) {
        this.adminService = adminService;
       
        
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Admin adminUser) {
        String email = adminUser.getEmail();
        String password = adminUser.getPassword();

        // Retrieve user details from the database
        Admin admin = adminService.findByEmail(email);
        if (admin == null) {
            return ResponseEntity.badRequest().body("Admin not found.");
        }

        // Validate admin email and password
        
        if (admin == null || !admin.getPassword().equals(password)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }

        // Successful authentication
        return ResponseEntity.ok("Login successful.");
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody Admin adminUser) {
        String email = adminUser.getEmail();
        String password = adminUser.getPassword();

        // Perform server-side validation
        if (email == null || password == null) {
            return ResponseEntity.badRequest().body("Email and password are required.");
        }
        
     // Validate email format using regex
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        if (!email.matches(emailRegex)) {
            return ResponseEntity.badRequest().body("Invalid email format.");
        }

        // Validate password complexity using regex
        String passwordRegex = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).{8,}$";
        if (!password.matches(passwordRegex)) {
            return ResponseEntity.badRequest().body("Password must meet complexity requirements.");
        }
        
        
        // Create a new Admin object and set the properties
        Admin newAdmin = new Admin();
        newAdmin.setEmail(email);
        newAdmin.setPassword(password);

        // Save the new admin user to the database
        adminService.saveAdmin(newAdmin);

     
        return ResponseEntity.ok("Admin user registered successfully.");
    }
    
    @GetMapping("/getAll")
    public ResponseEntity<List<Admin>> getAllAdmins() {
        List<Admin> admins = adminService.getAllAdmins();
        
        if (admins.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        
        return ResponseEntity.ok(admins);
    }

}

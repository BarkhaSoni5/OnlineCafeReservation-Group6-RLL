package com.springbootbackend.controller;


import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springbootbackend.Service.Itemservice;
import com.springbootbackend.model.ItemModel;


@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/cafe")
@RestController
public class itemController {
	
	@Autowired
	private Itemservice itemservice;
	
	@GetMapping("/item/{id}")
    public ResponseEntity<ItemModel> getItemById(@PathVariable int id) {
        ItemModel item = itemservice.getItemById(id);
        if (item != null) {
            return new ResponseEntity<>(item, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/item")
    public ResponseEntity<Iterable<ItemModel>> getAllItems() {
        Iterable<ItemModel> items = itemservice.getAllItems();
        return new ResponseEntity<>(items, HttpStatus.OK);
    }

    @PostMapping("/item")
    public ResponseEntity<ItemModel> addItem(@RequestBody ItemModel newItem) {
        ItemModel addedItem = itemservice.addItem(newItem);
        return new ResponseEntity<>(addedItem, HttpStatus.CREATED);
    }

    @PutMapping("/item/{id}")
    public ResponseEntity<ItemModel> updateItem(@PathVariable int id, @RequestBody ItemModel updatedItem) {
        ItemModel item = itemservice.updateItem(id, updatedItem);
        if (item != null) {
            return new ResponseEntity<>(item, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/item/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable int id) {
        itemservice.deleteItem(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    

    @PostMapping("/enable/{id}")
    public ItemModel enableItem(@PathVariable int id) {
        return itemservice.enableItem(id);
    }

    @PostMapping("/disable/{id}")
    public ItemModel disableItem(@PathVariable int id) {
        return itemservice.disableItem(id);
    }


}

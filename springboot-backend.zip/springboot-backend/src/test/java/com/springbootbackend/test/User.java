package com.springbootbackend.test;

public class User {
	
	

}

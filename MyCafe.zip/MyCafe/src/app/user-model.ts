export class User{
    id : number;
    firstName :string;
    lastName : number;
    emailId : string;
    phone : string;
    password : string;
    
}

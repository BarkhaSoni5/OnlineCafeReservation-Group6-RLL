export class ItemModel {
    id: number;
    itemname: string;
    itemprice: string;
    itemdesc: string;
    status: string;
  }
  
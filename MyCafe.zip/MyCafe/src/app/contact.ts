export class Contact {
    id:number;
    name:string;
    email:string;
    message:string
}
